// lib/constants/api_key.dart
class ApiKey {
  static const String openaiApiKey = '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';
}