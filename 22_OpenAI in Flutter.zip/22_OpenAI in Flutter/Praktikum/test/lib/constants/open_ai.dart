// lib/constants/open_ai.dart
import 'package:test/constants/api_key.dart';

String apiKey = ApiKey.openaiApiKey;