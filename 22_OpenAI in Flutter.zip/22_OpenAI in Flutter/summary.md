Rangkuman materi Form Input :

1. Form adalah sebuah widget yang berfungsi untuk mengelompokkan beberapa macam input field sehingga aplikasi dapat mengolah/memproses data dengan mudah dan lebih efisien

2. Input field merupakan sebuah widget dimana pengguna dapat memasukkan berbagai macam informasi yang dibutuhkan sesuai dari ketentuan aplikasi. Beberapa jenis input field dalam flutter ada TextField, Checkbox, Radio dan Dropdown button 

3. Button merupakan suatu widget yang dapat melakukan fungsi tertentu saat ditekan. beberapa jenis button dalam flutter ada ElevatedButton, TextButton, dan IconButton

Rangkuman materi Advance Form : 

1. Date Picker merupakan sebuah widget berbentuk kalender yang memungkinkan user untuk memilih input tanggal yang diinginkan dari kalender

2. Color Picker merupakan sebuah widget berbentuk list palet warna yang memungkinkan user untuk memilih input warna yang ingin digunakan dalam aplikasi

3. File Picker merupakan sebuah widget yang memungkinkan user untuk memilih dan mengupload file/dokumen dari dalam storage device user untuk digunakan pada kebutuhan aplikasi